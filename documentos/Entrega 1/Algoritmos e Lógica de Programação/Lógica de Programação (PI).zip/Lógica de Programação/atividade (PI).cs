using System;

class Program
{
    static void Main()
    {
        int energia = 3;
        int pontos = 0;
        int fase = 1;
        string opcao;

        Console.WriteLine("=== ESCAPE DO LABORATÓRIO ===");
        Console.WriteLine("Você dormiu e ficou preso no laboratório... precisa escapar!\n");

        while (energia > 0 && fase <= 3)
        {
            Console.WriteLine($"\n--- FASE {fase} ---");
            Console.WriteLine($"Energia: {energia} | Pontos: {pontos}");

            Console.WriteLine("Digite 'sair' para desistir ou pressione ENTER para continuar.");
            opcao = Console.ReadLine();

            if (opcao.ToLower() == "sair")
            {
                Console.WriteLine("Você decidiu esperar alguém abrir o laboratório...");
                break;
            }

            bool acertou = false;

            if (fase == 1)
            {
                Console.WriteLine("Pergunta: Quanto é 2 + 2?");
                string resposta = Console.ReadLine();

                if (resposta == "4")
                {
                    acertou = true;
                }
            }

            else if (fase == 2)
            {
                Console.WriteLine("Pergunta: Qual palavra-chave usamos para repetição em C#?");
                string resposta = Console.ReadLine().ToLower();

                if (resposta == "while")
                {
                    acertou = true;
                }
            }

            else if (fase == 3)
            {
                Console.WriteLine("Pergunta: Qual operador usamos para igualdade em C#?");
                string resposta = Console.ReadLine();

                if (resposta == "==")
                {
                    acertou = true;
                }
            }

            if (acertou)
            {
                Console.WriteLine("Resposta correta!");
                pontos += 10;
                fase++;
            }
            else
            {
                Console.WriteLine("Resposta errada!");
                energia--;
            }
        }

        Console.WriteLine("\n=== FIM DO JOGO ===");

        if (fase > 3)
        {
            Console.WriteLine("Você escapou do laboratório!");
            Console.WriteLine($"Pontuação final: {pontos}");
        }
        else if (energia == 0)
        {
            Console.WriteLine("Você ficou sem energia...");
        }
        else
        {
            Console.WriteLine("Você desistiu do jogo.");
        }
    }
}